"""
Original code snippets from the following project:
https://github.com/AwordaProject/Aworda-LBot
"""
