from pathlib import Path

from library import config

ASSETS = Path(Path(__file__).parent, "assets")
chitung_prefix = f"{config.func.prefix}qt"
